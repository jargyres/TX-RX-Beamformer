#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define BUF_SIZE 5


void smash(char *arg)
{
    char buffer[BUF_SIZE];

    strcpy(buffer, arg);

}

void uncalled()
{
    char* secret_string = "sekkrit stuff!";

    puts(secret_string);

    exit(0);

}

void main(int argc, char* argv[])
{
    char* arg = argv[1];
    smash(arg);

}

